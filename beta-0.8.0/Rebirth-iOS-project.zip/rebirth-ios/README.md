# Rebirth for iPhone and iPad

The game itself is in `Rebirth/www` (the same game as the web version, running fully offline, solo play).
The app is a small full-screen shell around it.

## Build it without a Mac (GitHub)
1. Join the Apple Developer Program ($99 a year) at developer.apple.com.
2. In App Store Connect, create the app with bundle ID `com.rebirth.game`.
3. In App Store Connect > Users and Access > Integrations > App Store Connect API, create a key with the "App Manager" role. Download the .p8 file and note the Key ID and Issuer ID.
4. Put this folder in a new GitHub repository (private is fine).
5. In the repository, Settings > Secrets and variables > Actions, add:
   - `APPLE_TEAM_ID` (Membership details on developer.apple.com)
   - `ASC_KEY_ID`, `ASC_ISSUER_ID`
   - `ASC_KEY_P8` (the whole text of the .p8 file)
6. Actions tab > iOS > Run workflow. After about 15 minutes the build appears in TestFlight.
7. In TestFlight, add testers by email or turn on a public link (up to 10,000 testers).

## Build it on a Mac
`brew install xcodegen && xcodegen generate`, open `Rebirth.xcodeproj`, pick your team under Signing, then Product > Archive.

## Updating the game
Replace the files in `Rebirth/www` with the new web version (keep the first `<script>` lines that load `lib/three.min.js` locally).
