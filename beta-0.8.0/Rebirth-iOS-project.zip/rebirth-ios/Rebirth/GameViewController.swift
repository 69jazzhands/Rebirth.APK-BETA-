import UIKit
import WebKit

/// Runs the bundled game (the www folder) full screen.
/// Files are served from a private "rebirth://" address so the game can load its own textures, models and saves.
final class GameViewController: UIViewController, WKNavigationDelegate {
    private var web: WKWebView!

    override func loadView() {
        let config = WKWebViewConfiguration()
        config.setURLSchemeHandler(LocalFiles(), forURLScheme: "rebirth")
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.websiteDataStore = .default()
        web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 0.043, green: 0.047, blue: 0.055, alpha: 1)
        web.scrollView.isScrollEnabled = false
        web.scrollView.bounces = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        if #available(iOS 16.4, *) { web.isInspectable = true }
        view = web
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        UIApplication.shared.isIdleTimerDisabled = true
        // Starts on Max graphics like Android and steps itself down if the phone is slow.
        // If iOS ever shut the game down for using too much memory, start on Medium from then on.
        // Low Power Mode caps web games at 30 frames a second, so start lighter there too.
        let safe = UserDefaults.standard.bool(forKey: "rebirthSafeGraphics") || ProcessInfo.processInfo.isLowPowerModeEnabled
        web.load(URLRequest(url: URL(string: safe ? "rebirth://game/index.html?qd=3" : "rebirth://game/index.html")!))
        NotificationCenter.default.addObserver(self, selector: #selector(sendHeat), name: ProcessInfo.thermalStateDidChangeNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(checkUpdate), name: UIApplication.willEnterForegroundNotification, object: nil)
    }

    /// Tells the game how hot the phone is (0 cool ... 3 very hot) so it can lower graphics before iOS slows the phone down.
    @objc private func sendHeat() {
        DispatchQueue.main.async {
            let level: Int
            switch ProcessInfo.processInfo.thermalState {
            case .nominal: level = 0
            case .fair: level = 1
            case .serious: level = 2
            case .critical: level = 3
            @unknown default: level = 0
            }
            self.web.evaluateJavaScript("window.rebirthNativeHeat && rebirthNativeHeat(\(level), 'ios')", completionHandler: nil)
        }
    }

    /// Once the game has loaded: what it's running on (for the test report) and the current temperature.
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        let d = UIDevice.current
        var sys = utsname(); uname(&sys)
        let model = withUnsafePointer(to: &sys.machine) { $0.withMemoryRebound(to: CChar.self, capacity: 1) { String(cString: $0) } }
        let info = "iOS \(d.systemVersion) app, \(model), low power mode \(ProcessInfo.processInfo.isLowPowerModeEnabled ? "on" : "off")"
        webView.evaluateJavaScript("window.REBIRTH_NATIVE_INFO = '\(info)';", completionHandler: nil)
        sendHeat()
        DispatchQueue.main.asyncAfter(deadline: .now() + 20) { [weak self] in self?.checkUpdate() }
    }

    /// Looks for a newer game on the server (at most every 30 minutes) and tells the game when it is ready.
    private var lastCheck = Date.distantPast
    @objc private func checkUpdate() {
        guard Date().timeIntervalSince(lastCheck) > 30 * 60 else { return }
        lastCheck = Date()
        LiveUpdate.shared.check { [weak self] version in
            DispatchQueue.main.async {
                let v = version.replacingOccurrences(of: "'", with: "")
                self?.web.evaluateJavaScript("window.rebirthUpdateReady && rebirthUpdateReady('\(v)')", completionHandler: nil)
            }
        }
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge { .all }

    // If the game's page is shut down, reload instead of showing a blank screen
    // (iOS does this when the game uses too much memory), so the restart uses Medium graphics.
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        UserDefaults.standard.set(true, forKey: "rebirthSafeGraphics")
        webView.load(URLRequest(url: URL(string: "rebirth://game/index.html?q=3")!))
    }

    // Keep the game inside the app; open outside links in Safari.
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = action.request.url, url.scheme != "rebirth", url.scheme != "about", url.scheme != "data", url.scheme != "blob" {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }
}

/// Serves the game: the newest downloaded files first (see LiveUpdate), then the copy inside the app.
final class LocalFiles: NSObject, WKURLSchemeHandler {
    private let bundled = Bundle.main.resourceURL!.appendingPathComponent("www").standardizedFileURL

    func webView(_ webView: WKWebView, start task: WKURLSchemeTask) {
        guard let url = task.request.url else { return }
        var path = url.path
        if path.isEmpty || path == "/" { path = "/index.html" }
        if path == "/index.html" { LiveUpdate.shared.promote() }
        let rel = String(path.dropFirst())
        var data: Data? = nil
        if let dir = LiveUpdate.shared.active {
            let f = dir.appendingPathComponent(rel).standardizedFileURL
            if f.path.hasPrefix(dir.path + "/") { data = try? Data(contentsOf: f) }
        }
        if data == nil {
            let f = bundled.appendingPathComponent(rel).standardizedFileURL
            if f.path.hasPrefix(bundled.path + "/") { data = try? Data(contentsOf: f) }
        }
        guard let body = data else { task.didFailWithError(URLError(.fileDoesNotExist)); return }
        let headers = ["Content-Type": LocalFiles.mime((rel as NSString).pathExtension), "Content-Length": String(body.count), "Access-Control-Allow-Origin": "*", "Cache-Control": "no-cache"]
        task.didReceive(HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: headers)!)
        task.didReceive(body)
        task.didFinish()
    }

    func webView(_ webView: WKWebView, stop task: WKURLSchemeTask) {}

    static func mime(_ ext: String) -> String {
        switch ext.lowercased() {
        case "html": return "text/html; charset=utf-8"
        case "js": return "text/javascript; charset=utf-8"
        case "json": return "application/json"
        case "jpg", "jpeg": return "image/jpeg"
        case "png": return "image/png"
        case "webp": return "image/webp"
        case "css": return "text/css"
        case "wasm": return "application/wasm"
        case "md", "txt": return "text/plain; charset=utf-8"
        default: return "application/octet-stream"
        }
    }
}
