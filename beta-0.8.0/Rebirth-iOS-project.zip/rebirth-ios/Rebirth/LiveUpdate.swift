import Foundation
import CryptoKit

/// Keeps the game up to date from the Rebirth server without a new app build.
///
/// The app ships with a full copy of the game (www) and its version.json (every file's size and SHA-256).
/// In the background it reads the server's version.json; if the server has a newer build it downloads only the
/// files that differ, checks each one's SHA-256, and keeps them in Application Support. The new version starts the
/// next time the game page loads (the in-game Restart button, or the next launch), so a game in progress never mixes
/// old and new files. With no connection the game runs the newest copy it already has, and a newer app build
/// always wins over older downloads.
final class LiveUpdate {
    static let shared = LiveUpdate()
    static let server = "https://rebirth-game.duckdns.org"

    private let defaults = UserDefaults.standard
    private let bundled = Bundle.main.resourceURL!.appendingPathComponent("www")
    private let base: URL
    private let bundledBuild: Int64
    private(set) var active: URL?
    private var busy = false

    private init() {
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        base = support.appendingPathComponent("live").standardizedFileURL
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        var excluded = base; var rv = URLResourceValues(); rv.isExcludedFromBackup = true; try? excluded.setResourceValues(rv)
        bundledBuild = LiveUpdate.readBuild(bundled.appendingPathComponent("version.json"))
        active = nil
        active = dir(for: Int64(defaults.integer(forKey: "liveActive")))
    }

    private static func readJSON(_ url: URL) -> [String: Any]? {
        guard let d = try? Data(contentsOf: url) else { return nil }
        return (try? JSONSerialization.jsonObject(with: d)) as? [String: Any]
    }
    private static func readBuild(_ url: URL) -> Int64 { (readJSON(url)?["build"] as? NSNumber)?.int64Value ?? 0 }
    private static func files(_ json: [String: Any]?) -> [String: [Any]] { (json?["files"] as? [String: [Any]]) ?? [:] }
    private static func hash(_ entry: [Any]?) -> String? { entry?.count ?? 0 > 1 ? entry?[1] as? String : nil }

    /// A downloaded build's folder, if it is complete and newer than the copy inside the app.
    private func dir(for build: Int64) -> URL? {
        guard build > bundledBuild else { return nil }
        let d = base.appendingPathComponent(String(build)).standardizedFileURL
        return FileManager.default.fileExists(atPath: d.appendingPathComponent("version.json").path) ? d : nil
    }

    /// Switches to a finished download. Only called when the game page itself (index.html) is requested.
    func promote() {
        let p = Int64(defaults.integer(forKey: "livePending"))
        if p > Int64(defaults.integer(forKey: "liveActive")), let d = dir(for: p) {
            defaults.set(Int(p), forKey: "liveActive"); defaults.removeObject(forKey: "livePending")
            active = d
        }
    }

    func check(ready: @escaping (String) -> Void) {
        if busy { return }
        busy = true
        DispatchQueue.global(qos: .utility).async {
            defer { self.busy = false }
            do { if let v = try self.update() { ready(v) } } catch { NSLog("Rebirth live update: \(error)") }
        }
    }

    private func get(_ path: String, _ timeout: TimeInterval) throws -> Data {
        guard let url = URL(string: LiveUpdate.server + "/" + path) else { throw URLError(.badURL) }
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        req.httpMethod = "GET"
        let sem = DispatchSemaphore(value: 0)
        var out: Result<Data, Error> = .failure(URLError(.timedOut))
        URLSession.shared.dataTask(with: req) { d, r, e in
            if let e = e { out = .failure(e) }
            else if let h = r as? HTTPURLResponse, h.statusCode == 200, let d = d { out = .success(d) }
            else { out = .failure(URLError(.badServerResponse)) }
            sem.signal()
        }.resume()
        sem.wait()
        return try out.get()
    }

    private static func sha256(_ d: Data) -> String { SHA256.hash(data: d).map { String(format: "%02x", $0) }.joined() }

    /// Returns the new version's name once it is downloaded and ready, or nil if there is nothing new.
    private func update() throws -> String? {
        let raw = try get("version.json", 10)
        guard let remote = (try JSONSerialization.jsonObject(with: raw)) as? [String: Any] else { return nil }
        let build = (remote["build"] as? NSNumber)?.int64Value ?? 0
        let have = max(bundledBuild, Int64(defaults.integer(forKey: "liveActive")), Int64(defaults.integer(forKey: "livePending")))
        guard build > have else { return nil }
        let fm = FileManager.default
        let mine = LiveUpdate.files(LiveUpdate.readJSON(bundled.appendingPathComponent("version.json")))
        let cur = active
        let curFiles = cur.map { LiveUpdate.files(LiveUpdate.readJSON($0.appendingPathComponent("version.json"))) } ?? [:]
        let tmp = base.appendingPathComponent("\(build).part")
        try? fm.removeItem(at: tmp)
        try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
        for (path, entry) in LiveUpdate.files(remote) {
            if path.contains("..") { continue }
            guard let h = LiveUpdate.hash(entry) else { continue }
            if LiveUpdate.hash(mine[path]) == h { continue }                       // same as the app's own copy
            let out = tmp.appendingPathComponent(path)
            try fm.createDirectory(at: out.deletingLastPathComponent(), withIntermediateDirectories: true)
            if let c = cur, LiveUpdate.hash(curFiles[path]) == h, fm.fileExists(atPath: c.appendingPathComponent(path).path) {
                try fm.copyItem(at: c.appendingPathComponent(path), to: out)        // already downloaded before
                continue
            }
            var data = try get(path, 30)
            if LiveUpdate.sha256(data) != h { data = try get(path, 30) }
            guard LiveUpdate.sha256(data) == h else { throw URLError(.cannotDecodeContentData) }
            if path == "index.html", let html = String(data: data, encoding: .utf8) { data = Data(ownFlags(html).utf8) }
            try data.write(to: out)
        }
        try raw.write(to: tmp.appendingPathComponent("version.json"))
        let dest = base.appendingPathComponent(String(build))
        try? fm.removeItem(at: dest)
        try fm.moveItem(at: tmp, to: dest)
        defaults.set(Int(build), forKey: "livePending")
        // tidy up older downloads
        for f in (try? fm.contentsOfDirectory(at: base, includingPropertiesForKeys: nil)) ?? [] {
            if f.lastPathComponent != String(build) && f.standardizedFileURL != cur?.standardizedFileURL { try? fm.removeItem(at: f) }
        }
        return remote["version"] as? String ?? ""
    }

    /// The server's page says "this is the web version"; the app's copy says "this is the iPhone app".
    private func ownFlags(_ html: String) -> String {
        let pattern = "<script id=\"rebirth-flags\">[^<]*</script>"
        guard let mineHtml = try? String(contentsOf: bundled.appendingPathComponent("index.html"), encoding: .utf8),
              let r = mineHtml.range(of: pattern, options: .regularExpression),
              let t = html.range(of: pattern, options: .regularExpression) else { return html }
        return html.replacingCharacters(in: t, with: String(mineHtml[r]))
    }
}
